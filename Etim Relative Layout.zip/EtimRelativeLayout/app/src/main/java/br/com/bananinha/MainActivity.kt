package br.com.bananinha

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import br.com.bananinha.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)
        // Listener vai ficar ouvindo o teclado pra ver onde vai clicar
        binding.imageSaldo.setOnClickListener{
            //clicando na imagem, ela vai criar uma intençao de mudar de tela com o INtent
            val mudarDeTela = Intent(this, Saldo::class.java)
            //o Intent precisa saber a tyela que estaamos e a tela que queremos ir

            //o startActivity efetivamente muda de tela
            startActivity(mudarDeTela)
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

}